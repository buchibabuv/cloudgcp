import logging
import os
import requests
import json
import psycopg2
from sqlalchemy import pool
import time
# Install Google Libraries
from google.cloud import secretmanager

def getconnection():
    # Setup the Secret manager Client
    client = secretmanager.SecretManagerServiceClient()
    # Get the sites environment credentials
    #secretkey = os.environ["Secretkey"]
    secretkey = os.environ.get("Secretkey")
    project_id = os.environ.get("projectid")
    secret_name = os.environ.get("secretvalue")

    # Get the secret for Slack
    #secret_name = "slack-hook-key"
    resource_name = f"projects/{project_id}/secrets/{secret_name}/versions/latest"
    #resource_name = secretkey
    print("Printing the secret key path :{}".format(secretkey))
    response = client.access_secret_version(resource_name)
    keyvalue = response.payload.data.decode('UTF-8')
    #print(keyvalue)
    value=json.loads(keyvalue)
    #print(value["username"])
    #print(value["password"])
    #Assign values from secretkey
    username=value["username"]
    pwd=value["password"]
    hostname=value["hostname"]
    portno=value["portno"]
    dbname=value["database"]
    
    connection = psycopg2.connect(user = username ,
                                  password = pwd,
                                  host = hostname, #"/cloudsql/bmg-imaoc-test:europe-west1:tst-dtpgsql-imaoc-inst",
                                  port = portno,#"5432",
                                  database = dbname #"imaoc_staging"
                                 # database = ""
                                  )
    return connection                        

def process_file(event, context):
    file = event
    #print(f"Processing file: {file['name']}.")

    print("Start the function")
    mypool = pool.QueuePool(getconnection, max_overflow=10, pool_size=5)
    conn = mypool.connect()
    cursor = conn.cursor()
    # Print PostgreSQL conn properties
    print ( "Connection Parameter: ",conn.get_dsn_parameters(),"\n")
    time.sleep(10)    
    # Print PostgreSQL version
    cursor.execute("SELECT version();")
    record = cursor.fetchone()
    print("You are connected to - ", record,"\n")
    conn.close()